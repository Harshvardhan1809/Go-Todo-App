### Legends &amp; Supporters

I really need to thank each one of them because they stood up[♡](https://github.com/go-siris/siris#support) to keep this project alive and active.

[Juan Sebastián Suárez Valencia](https://github.com/Juanses) donated 20 EUR at September 11 of 2016

[Bob Lee](https://github.com/li3p) donated 20 EUR at September 16 of 2016

[Celso Luiz](https://github.com/celsosz) donated 50 EUR at September 29 of 2016

[Ankur Srivastava](https://github.com/ansrivas) donated 20 EUR at October 2 of 2016

[Damon Zhao](https://github.com/se77en) donated 20 EUR at October 21 of 2016

[exponity - consulting & digital transformation](https://github.com/exponity) donated 30 EUR at November 4 of 2016

[Thomas Fritz](https://github.com/thomasfr) donated 25 EUR at Jenuary 8 of 2017

[Thanos V.](http://mykonosbiennale.com/) donated 20 EUR at Jenuary 16 of 2017

[George Opritescu](https://github.com/International) donated 20 EUR at February 7 of 2017

[Lex Tang](https://github.com/lexrus) donated 20 EUR at February 22 of 2017

[Conrad Steenberg](https://github.com/hengestone) donated 25 EUR at March 23 of 2017

<p>

<a href="https://medium.com/@kataras/a-url-shortener-service-using-go-iris-and-bolt-4182f0b00ae7">
<img width="300" src="http://go-siris.com/comment28.png" />
</a>

<a href="https://twitter.com/gelnior/status/769100480706379776">
<img width="300" src="http://go-siris.com/comment27.png" />
</a>

<br/>

<a href="https://www.youtube.com/watch?v=jGx0LkuUs4A">
<img  width="300" src="https://github.com/iris-contrib/website/raw/gh-pages/assets/gif_link_to_yt.gif" alt="What people say" />
</a>

<a href="https://www.youtube.com/watch?v=jGx0LkuUs4A">
<img width ="300" src="https://github.com/iris-contrib/website/raw/gh-pages/assets/gif_link_to_yt2.gif" alt="What people say" />
</a>

<br/>

<a href="https://twitter.com/_mgale/status/818591490305761280">
<img width="300" width="630" src="http://go-siris.com/comment25.png" />
</a>

<a href="https://twitter.com/MeAlex07/status/822799954188075008">
<img width="300" width="627" src="http://go-siris.com/comment26.png" />
</a>

</p>