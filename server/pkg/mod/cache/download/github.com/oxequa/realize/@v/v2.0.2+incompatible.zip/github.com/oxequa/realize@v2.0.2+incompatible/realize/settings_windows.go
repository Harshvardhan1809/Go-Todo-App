// +build windows

package realize

// Flimit defines the max number of watched files
func (s *Settings) Flimit() error {
	return nil
}
